package Images;

import java.util.ArrayList;

public class sources {
	

	public sources() {	
	}
	public String[] getCavalry() {
		String[]Cavalaries = {"src/Images/cavalary15.jpg","src/Images/cavalary16.jpg","src/Images/cavalary17.jpg","src/Images/cavalary20.jpg","src/Images/Cavalary5.jpg","src/Images/Cavalary6.jpg","src/Images/Cavalary7.jpg","src/Images/Cavalary8.jpg","src/Images/Cavalary9.jpg"};
		return Cavalaries;
	}
	
	public String[] getCity() {
		String[]Cities= {"src/Images/City1.jpg","src/Images/City2.jpg","src/Images/City3..jpg","src/Images/City4.jpg","src/Images/City5.jpg"};
		return Cities;
	}
	
	public String[] getGold() {
		String[] GoldPH= {"src/Images/gool.jpg","src/Images/gold2.jpg"};
		return GoldPH;
	}
	public String[] getInfantary() {
		String[] InfantaryPh= {"src/Images/infantary15.jpg","src/Images/infantary18.jpg","src/Images/Infantary3.jpg","src/Images/Infantary4.jpg","src/Images/Infantary5.jpg","src/Images/Infantary6.jpg","src/Images/Infantary7.jpg","src/Images/Infantary8.jpg","src/Images/Infantary9.jpg"};
		return InfantaryPh;
	}
	public String[] getArcher() {
		String[] ArcherPh= {"src/Images/archer16.jpg" ,"src/Images/archer18.jpg" , "src/Images/archer20.jpg" , "src/Images/archer21.jpg" ,"src/Images/archer16.jpg"}; 
			return ArcherPh;
	}
	public String[] getArmy() {
		String[] ArmyPh= {"src/Images/army1.jpg" ,"src/Images/army2.jpg" , "src/Images/army3.jpg" , "src/Images/army5.jpg" }; 
			return ArmyPh;
	}
	
	public String[] getBarracks() {
		String[] BarracksPh= {"src/Images/Barracks (2).jpg" , "src/Images/barracks145.jpg"}; 
			return BarracksPh;
	}
	
	
	

}